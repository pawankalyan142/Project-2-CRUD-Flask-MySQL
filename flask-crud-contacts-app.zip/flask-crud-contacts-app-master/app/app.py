from flask import Flask

# Application initializations
app = Flask(__name__)

'''
Flask uses the app.secret_key to secure and protect user sessions. When a user interacts with a web application, 
the server needs a way to identify and maintain the user's session across multiple requests. 
'''
app.secret_key = "mysecretkey"
